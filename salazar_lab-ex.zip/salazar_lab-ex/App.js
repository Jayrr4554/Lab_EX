import React, { useState } from 'react';
import { SafeAreaView, ScrollView, View, Text, Image, TouchableOpacity, StyleSheet } from 'react-native';

const App = () => {
  const [currentSection, setCurrentSection] = useState('name');

  const resumeData = {
    imageUrl: require('./unnamed.jpg'),
    name: 'Jay-R Salazar',
    course: ' Bachelor of Science in Information Technology',
    education: {
      elementary: 'Libis Baesa Elementary School',
      elementaryYear: '2012',
      highschool: 'Kasarinlan High School',
      highschoolYear: '2016',
      college: 'Global Reciprocal Colleges',
      collegeYear: '2026',
    },
    about: 'I am an IT student currently studying at Global Reciprocal Colleges.Third year College in second semester.',
    projects: {
      projectName: "BrewsTea",
      imageSrc: 'https://cdn-icons-png.flaticon.com/512/703/703017.png',
      link: 'https://www.facebook.com/Brewsteacafe/about',
      description: 'The project is named Integrated Ordering, Sales, and Inventory Management System, which enables customers to place orders online while allowing real-time monitoring of sales and inventory within the company'

    },
    contact: {
      mobile: '09666518581',
      email: 'jayrr4554@gmail.cocm',
    },
  };

  const handlePress = () => {
    setCurrentSection((prevSection) => {
      switch (prevSection) {
        case 'name':
          return "education";
        case 'education':
          return 'about';
        case 'about':
          return 'projects';
        case 'projects':
          return 'contact';
        case 'contact':
          return 'name';
        default:
          return 'name';
      }
    });
  };

  return (
    <SafeAreaView style={{ flex: 1 }}>
      <ScrollView contentContainerStyle={styles.container}>
        <TouchableOpacity onPress={handlePress} style={styles.contentContainerStyle}>
          {currentSection === 'name' && (
            <>
              <Image source={resumeData.imageUrl} style={styles.image} />
              <View style={styles.textContainer}>
                <Text style={styles.header}>{resumeData.name}</Text>
                <Text style={styles.info}>{resumeData.course}</Text>
              </View>
            </>
          )}

          {currentSection === 'education' && (
            <View style={styles.textContainer}>
              <Text style={styles.header}>Education</Text>
              <Text>{`\nCollege: ${resumeData.education.college} | ${resumeData.education.collegeYear}`}</Text>
              <Text>{`\nHigh School: ${resumeData.education.highschool} | ${resumeData.education.highschoolYear}`}</Text>
              <Text>{`\nElementary: ${resumeData.education.elementary} | ${resumeData.education.elementaryYear}`}</Text>
            </View>
          )}

          {currentSection === 'about' && (
            <View style={styles.textContainer}>
              <Text style={styles.header}>About me:</Text>
              <Text>{`\n${resumeData.about}`}</Text>
            </View>
          )}

          {currentSection === 'projects' && (
            <View style={styles.projectContainer}>
              <Text style={styles.header}>Projects:</Text>
              <Text style={styles.projectTitle}>{resumeData.projects.projectName}</Text>
              <Image source={{ uri: resumeData.projects.imageSrc }} style={styles.projectImage} />
              <Text style={styles.projectLink}>{resumeData.projects.link}</Text>
              <Text style={styles.projectDescription}>{resumeData.projects.description}</Text>
            </View>
          )}

          {currentSection === 'contact' && (
            <View style={styles.textContainer}>
              <Text style={styles.header}>Contact:</Text>
              <Text>{`\nMobile: ${resumeData.contact.mobile}`}</Text>
              <Text>{`\nEmail: ${resumeData.contact.email}`}</Text>
            </View>
          )}
        </TouchableOpacity>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flexGrow: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  contentContainerStyle: {
    flex: 1,
    alignItems: 'center',
    justifyContent: 'center',
  },
  image: {
    width: 100,
    height: 100,
    borderRadius: 50,
    marginBottom: 10,
  },
  textContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  header: {
    fontSize: 20,
    fontWeight: 'bold',
  },
  info: {
    fontSize: 16,
  },
  projectContainer: {
    alignItems: 'center',
    justifyContent: 'center',
    marginBottom: 20,
  },
  projectTitle: {
    fontSize: 18,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  projectImage: {
    width: 100,
    height: 100,
    marginBottom: 10,
  },
  projectLink: {
    color: 'blue',
    marginBottom: 5,
  },
  projectDescription: {
    fontSize: 14,
  },
});

export default App;
